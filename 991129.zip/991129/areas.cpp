


/*
  +---------------------------------------+
  | BETH YW? WELSH GOVERNMENT DATA PARSER |
  +---------------------------------------+

  AUTHOR: <991129>

  The file contains the Areas class implementation. Areas are the top
  level of the data structure in Beth Yw? for now.

  Areas is also responsible for importing data from a stream (using the
  various populate() functions) and creating the Area and Measure objects.

  This file contains numerous functions you must implement. Each function you
  must implement has a TODO block comment. 
*/

#include <stdexcept>
#include <iostream>
#include <string>
#include <stdexcept>
#include <tuple>
#include <unordered_set>
#include <sstream>
#include <fstream>

#include "lib_json.hpp"

#include "datasets.h"
#include "areas.h"
#include "measure.h"

/*
  An alias for the imported JSON parsing library.
*/
using json = nlohmann::json;

/*
  TODO: Areas::Areas()

  Constructor for an Areas object.

  @example
    Areas data = Areas();
*/
//: areasContainer(std::vector<Area>())
Areas::Areas() : areasContainer(std::map<std::string, Area>()) {
    //throw std::logic_error("Areas::Areas() has not been implemented!");
}

/*
  TODO: Areas::setArea(localAuthorityCode, area)

  Add a particular Area to the Areas object.

  If an Area already exists with the same local authority code, overwrite all
  data contained within the existing Area with those in the new
  Area (i.e. they should be combined, but the new Area's data should take
  precedence, e.g. replace a name with the same language identifier).

  @param localAuthorityCode
    The local authority code of the Area

  @param area
    The Area object that will contain the Measure objects

  @return
    void

  @example
    Areas data = Areas();
    std::string localAuthorityCode = "W06000023";
    Area area(localAuthorityCode);
    data.setArea(localAuthorityCode, area);
*/
void Areas::setArea(const std::string &localAuthorityCode, Area area) {
    //we find an area with the this localAuth code: update values if found
    if (areasContainer.find(localAuthorityCode) != areasContainer.end()) {
        Area newArea(localAuthorityCode);
        std::map<std::string, std::string> commonAreaNames = area.getNames();
        commonAreaNames.insert(areasContainer.find(localAuthorityCode)->second.getNames().begin(),
                               areasContainer.find(localAuthorityCode)->second.getNames().end());
        std::map<std::string, Measure> commonAreaMeasurements = area.getMeasurements();
        commonAreaMeasurements.insert(areasContainer.find(localAuthorityCode)->second.getMeasurements().begin(),
                                      areasContainer.find(localAuthorityCode)->second.getMeasurements().end());

        areasContainer.find(localAuthorityCode)->second.setNames(commonAreaNames);
        areasContainer.find(localAuthorityCode)->second.setMeasurements(commonAreaMeasurements);
    } else {
        this->areasContainer.insert(std::pair<std::string, Area>(localAuthorityCode, area));
    }
}


/*
  TODO: Areas::getArea(localAuthorityCode)

  Retrieve an Area instance with a given local authority code.

  @param localAuthorityCode
    The local authority code to find the Area instance of

  @return
    An Area object

  @throws
    std::out_of_range if an Area with the set local authority code does not
    exist in this Areas instance

  @example
    Areas data = Areas();
    std::string localAuthorityCode = "W06000023";
    Area area(localAuthorityCode);
    data.setArea(localAuthorityCode, area);
    ...
    Area area2 = areas.getArea("W06000023");
*/
Area &Areas::getArea(const std::string &localAuthorityCode) {
    if (this->areasContainer.find(localAuthorityCode) != this->areasContainer.end()) {
        //std::cout << currentArea.getLocalAuthorityCode() << std::endl;
        return this->areasContainer.find(localAuthorityCode)->second;
    }
    throw std::out_of_range("No area found matching " + localAuthorityCode);
}


/*
  TODO: Areas::size()

  Retrieve the number of Areas within the container. This function should be 
  callable from a constant context, not modify the state of the instance, and
  must promise not throw an exception.

  @return
    The number of Area instances

  @example
    Areas data = Areas();
    std::string localAuthorityCode = "W06000023";
    Area area(localAuthorityCode);
    data.setArea(localAuthorityCode, area);
    
    auto size = areas.size(); // returns 1
*/
unsigned int Areas::size() const {
    return this->getAreasContainer().size();
}


/*
  TODO: Areas::populateFromAuthorityCodeCSV(is, cols, areasFilter)

  This function specifically parses the compiled areas.csv file of local 
  authority codes, and their names in English and Welsh.

  This is a simple dataset that is a comma-separated values file (CSV), where
  the first row gives the name of the columns, and then each row is a set of
  data.

  For this coursework, you can assume that areas.csv will always have the same
  three columns in the same order.

  Once the data is parsed, you need to create the appropriate Area objects and
  insert them in to a Standard Library container within Areas.

  @param is
    The input stream from InputSource

  @param cols
    A map of the enum BethyYw::SourceColumnMapping (see datasets.h) to strings
    that give the column header in the CSV file

  @param areasFilter
    An umodifiable pointer to set of umodifiable strings for areas to import,
    or an empty set if all areas should be imported

  @return
    void

  @see
    See datasets.h for details of how the variable cols is organised

  @see
    See bethyw.cpp for details of how the variable areasFilter is created

  @example
    InputFile input("data/areas.csv");
    auto is = input.open();

    auto cols = InputFiles::AREAS.COLS;

    auto areasFilter = BethYw::parseAreasArg();

    Areas data = Areas();
    areas.populateFromAuthorityCodeCSV(is, cols, &areasFilter);

  @throws 
    std::runtime_error if a parsing error occurs (e.g. due to a malformed file)
    std::out_of_range if there are not enough columns in cols
*/
//
void Areas::populateFromAuthorityCodeCSV(std::istream &is, const BethYw::SourceColumnMapping &cols,
                                         const StringFilterSet *const areasFilter) {
    //check the filter isn't empty or null
    if (areasFilter == nullptr || areasFilter->empty()) {
        std::string line;
        //skip the first line
        std::getline(is, line);
        //get a line
        while (std::getline(is, line)) {
            // create the substrings and the populate in a Area
            std::string auth_code = line.substr(0, line.find(','));
            if (areasFilter == nullptr || areasFilter->empty() || areasFilter->find(auth_code) != areasFilter->end()) {
                std::string temp = line.substr(line.find(',') + 1);
                std::string nameEng = temp.substr(0, temp.find(','));
                std::string nameCym = temp.substr(temp.find(',') + 1);

                Area newArea(auth_code);
                newArea.setName("eng", nameEng);
                newArea.setName("cym", nameCym);
                setArea(auth_code, newArea);
            }

        }
    }
}

/*
  TODO: Areas::populateFromWelshStatsJSON(is,
                                          cols,
                                          areasFilter,
                                          measuresFilter,
                                          yearsFilter)

  Data from StatsWales is in the JSON format, and contains three
  top-level keys: odata.metadata, value, odata.nextLink. value contains the
  data we need. Rather than been hierarchical, it contains data as a
  continuous list (e.g. as you would find in a table). For each row in value,
  there is a mapping of various column headings and their respective vaues.

  Therefore, you need to go through the items in value (in a loop)
  using a JSON library. To help you, I've selected the nlohmann::json
  library that you must use for your coursework. Read up on how to use it here:
  https://github.com/nlohmann/json

  Example of using this library:
    - Reading/parsing in from a stream is very simply using the >> operator:
        json j;
        stream >> j;

    - Looping through parsed JSON is done with a simple for each loop. Inside
      the loop, you can access each using the array syntax, with the key/
      column name, e.g. data["Localauthority_ItemName_ENG"] gives you the
      local authority name:
        for (auto& el : j["value"].items()) {
           auto &data = el.value();
           std::string localAuthorityCode = data["Localauthority_ItemName_ENG"];
           // do stuff here...
        }

  In this function, you will have to parse the JSON datasets, extracting
  the local authority code, English name (the files only contain the English
  names), and each measure by year.

  If you encounter an Area that does not exist in the Areas container, you
  should create the Area object

  If areasFilter is a non-empty set only include areas matching the filter. If
  measuresFilter is a non-empty set only include measures matching the filter.
  If yearsFilter is not equal to <0,0>, only import years within the range
  specified by the tuple (inclusive).

  I've provided the column names for each JSON file that you need to parse
  as std::strings in datasets.h. This mapping should be passed through to the
  cols parameter of this function.

  Note that in the JSON format, years are stored as strings, but we need
  them as ints. When retrieving values from the JSON library, you will
  have to cast them to the right type.

  @param is
    The input stream from InputSource

  @param cols
    A map of the enum BethyYw::SourceColumnMapping (see datasets.h) to strings
    that give the column header in the CSV file

  @param areasFilter
    An umodifiable pointer to set of umodifiable strings of areas to import,
    or an empty set if all areas should be imported

  @param measuresFilter
    An umodifiable pointer to set of umodifiable strings of measures to import,
    or an empty set if all measures should be imported

  @param yearsFilter
    An umodifiable pointer to an umodifiable tuple of two unsigned integers,
    where if both values are 0, then all years should be imported, otherwise
    they should be treated as the range of years to be imported (inclusively)

  @return
    void

  @throws 
    std::runtime_error if a parsing error occurs (e.g. due to a malformed file)
    std::out_of_range if there are not enough columns in cols

  @see
    See datasets.h for details of how the variable cols is organised

  @see
    See bethyw.cpp for details of how the variable areasFilter is created

  @example
    InputFile input("data/popu1009.json");
    auto is = input.open();

    auto cols = InputFiles::DATASETS["popden"].COLS;

    auto areasFilter = BethYw::parseAreasArg();
    auto measuresFilter = BethYw::parseMeasuresArg();
    auto yearsFilter = BethYw::parseMeasuresArg();

    Areas data = Areas();
    areas.populateFromWelshStatsJSON(
      is,
      cols,
      &areasFilter,
      &measuresFilter,
      &yearsFilter);
*/
//std::istream &is, const BethYw::SourceColumnMapping &cols,
//                                       const StringFilterSet *const areasFilter
void Areas::populateFromWelshStatsJSON(std::istream &is,
                                       const BethYw::SourceColumnMapping &cols,
                                       const StringFilterSet *const areasFilter,
                                       const StringFilterSet *const measuresFilter,
                                       const YearFilterTuple *const yearsFilter) {

    std::string trainData = "http://open.statswales.gov.wales/en-gb/dataset/$metadata#tran0152";
    std::string enviData = "http://open.statswales.gov.wales/en-gb/dataset/$metadata#envi0201";
    std::string metadata = "odata.metadata";
    //read the JSON file:
    json j;
    is >> j;
    //loop through JSON value array:
    for (auto &el : j["value"].items()) {
        auto &data = el.value();
        //get what we need for area:
        std::string auth_code;
        std::string engName;
        bool accepted = false;
        auth_code = data[cols.find(BethYw::SourceColumn::AUTH_CODE)->second];
        engName = data[cols.find(BethYw::SourceColumn::AUTH_NAME_ENG)->second];
        if (areasFilter == nullptr || areasFilter->empty()) {
            accepted = true;
        } else if (areasFilter->find(auth_code) != areasFilter->end()
                   || areasFilter->find(engName) != areasFilter->end()) {
            accepted = true;
        }
        if (accepted == true) {
            Area newArea(auth_code);
            newArea.setName("eng", engName);
            std::string year = data[cols.find(BethYw::SourceColumn::YEAR)->second];
            unsigned int yearAsNum = std::stoi(year);
            bool year_accepted = false;
            if ((std::get<0>(*yearsFilter) == 0 && std::get<1>(*yearsFilter) == 0) || yearsFilter == nullptr) {
                year_accepted = true;
            } else if (std::get<0>(*yearsFilter) <= yearAsNum ||
                       std::get<1>(*yearsFilter) >= yearAsNum) { // find the range of the tuple its the two years
                year_accepted = true;
            }
            if (year_accepted) {

                std::string code;
                std::string name;
                if (j[metadata] == trainData) { // the code and name are hardcoded in so we need to get those
                    code = cols.find(BethYw::SourceColumn::SINGLE_MEASURE_CODE)->second;
                    name = cols.find(BethYw::SourceColumn::SINGLE_MEASURE_NAME)->second;
                } else { //otherwise get the code and name which is dataset dependent:
                    code = data[cols.find(BethYw::SourceColumn::MEASURE_CODE)->second];
                    name = data[cols.find(BethYw::SourceColumn::MEASURE_NAME)->second];
                    std::transform(code.begin(), code.end(), code.begin(), ::tolower);
                    double val = 0;
                    if (j[metadata] != enviData) {
                        val = data[cols.find(BethYw::SourceColumn::VALUE)->second];
                    } else {
                        std::string t = data[cols.find(BethYw::SourceColumn::VALUE)->second];
                        val = std::stod(t);
                    }
                    bool measures_accepted = false;
                    if (measuresFilter == nullptr || measuresFilter->empty()) {
                        measures_accepted = true;
                    } else if (measuresFilter->find(auth_code) != measuresFilter->end()
                               || measuresFilter->find(engName) != measuresFilter->end()) {
                        measures_accepted = true;
                    }
                    if (measures_accepted) {
                        Measure temp(code, name);
                        temp.setValue(yearAsNum, val);
                        newArea.setMeasure(code, temp);
                        setArea(auth_code, newArea);
                    }
                }

            }
        }
    }
}

/*
  TODO: Areas::populateFromAuthorityByYearCSV(is,
                                              cols,
                                              areasFilter,
                                              yearFilter)

  This function imports CSV files that contain a single measure. The 
  CSV file consists of columns containing the authority code and years.
  Each row contains an authority code and values for each year (or no value
  if the data doesn't exist).

  Note that these files do not include the names for areas, instead you 
  have to rely on the names already populated through 
  Areas::populateFromAuthorityCodeCSV();

  The datasets that will be parsed by this function are
   - complete-popu1009-area.csv
   - complete-popu1009-pop.csv
   - complete-popu1009-opden.csv

  @param is
    The input stream from InputSource

  @param cols
    A map of the enum BethyYw::SourceColumnMapping (see datasets.h) to strings
    that give the column header in the CSV file

  @param areasFilter
    An umodifiable pointer to set of umodifiable strings for areas to import,
    or an empty set if all areas should be imported

  @param measuresFilter
    An umodifiable pointer to set of strings for measures to import, or an empty 
    set if all measures should be imported

  @param yearsFilter
    An umodifiable pointer to an umodifiable tuple of two unsigned integers,
    where if both values are 0, then all years should be imported, otherwise
    they should be treated as a the range of years to be imported

  @return
    void

  @see
    See datasets.h for details of how the variable cols is organised

  @see
    See bethyw.cpp for details of how the variable areasFilter is created

  @example
    InputFile input("data/complete-popu1009-pop.csv");
    auto is = input.open();

    auto cols = InputFiles::DATASETS["complete-pop"].COLS;

    auto areasFilter = BethYw::parseAreasArg();
    auto yearsFilter = BethYw::parseYearsArg();

    Areas data = Areas();
    areas.populateFromAuthorityCodeCSV(is, cols, &areasFilter, &yearsFilter);

  @throws 
    std::runtime_error if a parsing error occurs (e.g. due to a malformed file)
    std::out_of_range if there are not enough columns in cols
*/
void Areas::populateFromAuthorityByYearCSV(std::istream &is,
                                           const BethYw::SourceColumnMapping &cols,
                                           const StringFilterSet *const areasFilter,
                                           const StringFilterSet *const measuresFilter,
                                           const YearFilterTuple *const yearsFilter) {

    // Indentation marker:

    throw std::logic_error(
            "Areas::populateFromAuthorityByYearCSV() has not been implemented!");
//    std::string line;
//    std::string header;
//    std::getline(is, header); // contains the headers.
//    std::vector<std::string> years;
//    std::string delim = ",";
//    size_t pos = line.find(',');
//    header.erase(0, pos + delim.length()); // erase the Authority code text;
//    while (size_t posL = header.find(',') != std::string::npos) { // make vectors of years:
//        years.push_back(header.substr(0, pos));
//        header.erase(0, pos + header.find(','));
//    }
//
//    for (auto &year : years) {
//        //get the auth code:
//        std::getline(is, line);
//        std::string auth_code = line.substr(0, line.find(','));
//        line.erase(0, pos + delim.length());// remove the auth_code from line:
//        //get area:
//        Area temp = getArea(auth_code);
//        //loop through the rest of the line:
//        while (size_t posx = line.find(',') != std::string::npos) {
//            //get list of measurements:
//        }
//    }
}


/*
  TODO: Areas::populate(is, type, cols)

  Parse data from an standard input stream `is`, that has data of a particular
  `type`, and with a given column mapping in `cols`.

  This function should look at the `type` and hand off to one of the three 
  functions populate………() functions.

  The function must check if the stream is in working order and has content.

  @param is
    The input stream from InputSource

  @param type
    A value from the BethYw::SourceDataType enum which states the underlying
    data file structure

  @param cols
    A map of the enum BethyYw::SourceColumnMapping (see datasets.h) to strings
    that give the column header in the CSV file

  @return
    void

  @throws 
    std::runtime_error if a parsing error occurs (e.g. due to a malformed file),
    the stream is not open/valid/has any contents, or an unexpected type
    is passed in.
    std::out_of_range if there are not enough columns in cols

  @see
    See datasets.h for details of the values variable type can have

  @see
    See datasets.h for details of how the variable cols is organised

  @see
    See bethyw.cpp for details of how the variable areasFilter is created

  @example
    InputFile input("data/popu1009.json");
    auto is = input.open();

    auto cols = InputFiles::DATASETS["popden"].COLS;

    Areas data = Areas();
    areas.populate(
      is,
      DataType::WelshStatsJSON,
      cols);
*/


/*
  TODO: Areas::populate(is,
                        type,
                        cols,
                        areasFilter,
                        measuresFilter,
                        yearsFilter)

  Parse data from an standard input stream, that is of a particular type,
  and with a given column mapping, filtering for specific areas, measures,
  and years, and fill the container.

  This function should look at the `type` and hand off to one of the three 
  functions you've implemented above.

  The function must check if the stream is in working order and has content.

  This overloaded function includes pointers to the three filters for areas,
  measures, and years.

  @param is
    The input stream from InputSource

  @param type
    A value from the BethYw::SourceDataType enum which states the underlying
    data file structure

  @param cols
    A map of the enum BethyYw::SourceColumnMapping (see datasets.h) to strings
    that give the column header in the CSV file

  @param areasFilter
    An umodifiable pointer to set of umodifiable strings for areas to import,
    or an empty set if all areas should be imported

  @param measuresFilter
    An umodifiable pointer to set of umodifiable strings for measures to import,
    or an empty set if all measures should be imported

  @param yearsFilter
    An umodifiable pointer to an umodifiable tuple of two unsigned integers,
    where if both values are 0, then all years should be imported, otherwise
    they should be treated as a the range of years to be imported

  @return
    void

  @throws 
    std::runtime_error if a parsing error occurs (e.g. due to a malformed file),
    the stream is not open/valid/has any contents, or an unexpected type
    is passed in.
    std::out_of_range if there are not enough columns in cols

  @see
    See datasets.h for details of the values variable type can have

  @see
    See datasets.h for details of how the variable cols is organised

  @see
    See bethyw.cpp for details of how the variables areasFilter, measuresFilter,
    and yearsFilter are created

  @example
    InputFile input("data/popu1009.json");
    auto is = input.open();

    auto cols = InputFiles::DATASETS["popden"].COLS;

    auto areasFilter = BethYw::parseAreasArg();
    auto measuresFilter = BethYw::parseMeasuresArg();
    auto yearsFilter = BethYw::parseMeasuresArg();

    Areas data = Areas();
    areas.populate(
      is,
      DataType::WelshStatsJSON,
      cols,
      &areasFilter,
      &measuresFilter,
      &yearsFilter);
*/
void Areas::populate(
        std::istream &is,
        const BethYw::SourceDataType &type,
        const BethYw::SourceColumnMapping &cols,
        const StringFilterSet *const areasFilter,
        const StringFilterSet *const measuresFilter,
        const YearFilterTuple *const yearsFilter) {
    if (type == BethYw::AuthorityCodeCSV) {
        //call on the populate from AuthorityCode
        populateFromAuthorityCodeCSV(is, cols, areasFilter);
    } else if (type == BethYw::AuthorityByYearCSV) {
        //call on populate from authority by year
        populateFromAuthorityByYearCSV(is, cols, areasFilter, measuresFilter, yearsFilter);
    } else if (type == BethYw::WelshStatsJSON) {
        populateFromWelshStatsJSON(is, cols, areasFilter, measuresFilter, yearsFilter);
    } else {
        throw std::runtime_error("Areas::populate: Unexpected data type");
    }
}

/*
  TODO: Areas::toJSON()

  Convert this Areas object, and all its containing Area instances, and
  the Measure instances within those, to values.

  Use the sample JSON library as above to create this. Construct a blank
  JSON object:
    json j;

  Convert this json object to a string:
    j.dump();

  You then need to loop through your areas, measures, and years/values
  adding this data to the JSON object.

  Read the documentation for how to convert your outcome code to JSON:
    https://github.com/nlohmann/json#arbitrary-types-conversions
  
  The JSON should be formatted as such:
    {
    "<localAuthorityCode1>" : {
                              "names": { "<languageCode1>": "<languageName1>",
                                         "<languageCode2>": "<languageName2>" 
                                         …
                                         "<languageCodeN>": "<languageNameN>" }, 
                              "measures" : { "<year1>": <value1>,
                                             "<year2>": <value2>,
                                             …
                                            "<yearN>": <valueN> }
                               },
    "<localAuthorityCode2>" : {
                              "names": { "<languageCode1>": "<languageName1>",
                                         "<languageCode2>": "<languageName2>" 
                                         …
                                         "<languageCodeN>": "<languageNameN>" }, 
                              "measures" : { "<year1>": <value1>,
                                             "<year2>": <value2>,
                                             …
                                            "<yearN>": <valueN> }
                               }
    ...
    "<localAuthorityCodeN>" : {
                              "names": { "<languageCode1>": "<languageName1>",
                                         "<languageCode2>": "<languageName2>" 
                                         …
                                         "<languageCodeN>": "<languageNameN>" }, 
                              "measures" : { "<year1>": <value1>,
                                             "<year2>": <value2>,
                                             …
                                            "<yearN>": <valueN> }
                               }
    }

  An empty JSON is "{}" (without the quotes), which you must return if your
  Areas object is empty.
  
  @return
    std::string of JSON

  @example
    InputFile input("data/popu1009.json");
    auto is = input.open();

    auto cols = InputFiles::DATASETS["popden"].COLS;

    auto areasFilter = BethYw::parseAreasArg();
    auto measuresFilter = BethYw::parseMeasuresArg();
    auto yearsFilter = BethYw::parseMeasuresArg();

    Areas data = Areas();
    std::cout << data.toJSON();
*/
std::string Areas::toJSON() const {
    json j;

    return j.dump();
}

const AreasContainer &Areas::getAreasContainer() const {
    return areasContainer;
}




/*
  TODO: operator<<(os, areas)

  Overload the << operator to print all of the imported data.

  Output should be formatted like the following to pass the tests. Areas should
  be printed, ordered alphabetically by their local authority code. Measures 
  within each Area should be ordered alphabetically by their codename.

  See the coursework specification for more information, although for reference
  here is a quick example of how output should be formatted:

    <English name of area 1> / <Welsh name of area 1> (<authority code 1>)
    <Measure 1 name> (<Measure 1 code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean 1> <diff 1> <diffp 1>

    <Measure 2 name> (<Measure 2 code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean 2> <diff 2> <diffp 2>

    <Measure 3 name> (<Measure 3 code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean 3> <diff 3> <diffp 3>

    ...

    <Measure x name> (<Measure x code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean x> <diff x> <diffp x>


    <English name of area 2> / <Welsh name of area 2> (<authority code 2>)
    <Measure 1 name> (<Measure 1 code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean 1> <diff 1> <diffp 1>

    <Measure 2 name> (<Measure 2 code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean 2> <diff 2> <diffp 2>

    <Measure 3 name> (<Measure 3 code>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean 3> <diff 3> <diffp 3>

    ...

    <Measure x name> (<Measure x code>)
     <year 1>  <year 2> <year 3> ...  <year n>
    <value 1>  <year 2> <year 3> ... <value n> <mean x> <diff x> <diffp x>

    ...

    <English name of area y> / <Welsh name of area y> (<authority code y>)
    <Measure 1 name> (<Measure 1 codename>)
     <year 1>  <year 2> <year 3> ...  <year n>
    <value 1>  <year 2> <year 3> ... <value n> <mean 1> <diff 1> <diffp 1>

    <Measure 2 name> (<Measure 2 codename>)
     <year 1>  <year 2> <year 3> ...  <year n>
    <value 1>  <year 2> <year 3> ... <value n> <mean 2> <diff 2> <diffp 2>

    <Measure 3 name> (<Measure 3 codename>)
     <year 1>  <year 2> <year 3> ...  <year n>
    <value 1>  <year 2> <year 3> ... <value n> <mean 3> <diff 3> <diffp 3>

    ...

    <Measure x name> (<Measure x codename>)
     <year 1>  <year 2> <year 3> ...  <year n>  Average    Diff.   % Diff.
    <value 1>  <year 2> <year 3> ... <value n> <mean x> <diff x> <diffp x>

  With real data, your output should start like this for the command
  bethyw --dir <dir> -p popden -y 1991-1993 (truncated for readability):

    Isle of Anglesey / Ynys Môn (W06000001)
    Land area (area) 
          1991       1992       1993    Average    Diff.  % Diff. 
    711.680100 711.680100 711.680100 711.680100 0.000000 0.000000 

    Population density (dens) 
         1991      1992      1993   Average    Diff.  % Diff. 
    97.126504 97.486216 98.038430 97.550383 0.911926 0.938905 

    Population (pop) 
            1991         1992         1993      Average      Diff.  % Diff. 
    69123.000000 69379.000000 69772.000000 69424.666667 649.000000 0.938906 


    Gwynedd / Gwynedd (W06000002)
    Land area (Area)
    ...

  @param os
    The output stream to write to

  @param areas
    The Areas object to write to the output stream

  @return
    Reference to the output stream

  @example
    Areas areas();
    std::cout << areas << std::end;
*/
//std::ostream &operator<<(std::ostream &os, const Areas &areas) {
//    for (auto it = measure.readings.begin(); it != areas.getAreasContainer(); ++it) {
//        os << "code: " << measure.code << " label: " << measure.label << " readings: " << it->first << it->second;
//    }
//    return os;
//}

